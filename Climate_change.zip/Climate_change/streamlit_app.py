import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

st.set_page_config(page_title="Climate Change Analysis", layout="wide")

# Load the climate data
@st.cache_data
def load_data():
    # Replace with your actual dataset file path
    data = pd.read_csv("climate_data.csv", encoding="latin1")
    return data

# Load the dataset
df = load_data()

# Sidebar for navigation
st.sidebar.title("Navigation")
option = st.sidebar.selectbox("Choose a tab", ["Data Visualization", "Prediction", "Analysis"])

# Styling the app
st.markdown("""
    <style>
    .main {
        background-color: #f0f2f6;
    }
    .sidebar .sidebar-content {
        background-color: #f0f2f6;
    }
    </style>
    """, unsafe_allow_html=True)

if option == "Data Visualization":
    st.title("Data Visualization")
    st.write("Explore the climate data with interactive visualizations.")

    # Data check
    st.write("Sample of the data:")
    st.write(df.head())

    # Sidebar for selecting visualization type
    visualization_type = st.sidebar.radio(
        "Choose a visualization type:",
        ["Heatmap","Grouped Bar Chart","Area Plot","Line Plot","Bar Chart","Choropleth Map","Scatter Plot"]
    )
    
    if visualization_type =="Heatmap":
        if 'Avg Temperature (°C)' in df.columns and 'Country' in df.columns and 'Continent' in df.columns:
            # Check if there's data after filtering
            fig1 = px.imshow(
                df.pivot_table(
                    index='Country', columns='Year', values='Avg Temperature (°C)', aggfunc='mean'
                ),
                color_continuous_scale='bluered',
                labels={'color': 'Avg Temp (°C)'},
                title=f"Heatmap of Avg Temperature (°C) for all countries"
            )
            st.plotly_chart(fig1)
        else:
            st.write("Required columns for the heatmap are missing.")
        
    elif visualization_type =="Grouped Bar Chart":
        if 'CO2 Emissions (Tons/Capita)' in df.columns and 'Country' in df.columns and 'Continent' in df.columns:
            # Create a selectbox to filter by year
            selected_year = st.selectbox("Select a Year", sorted(df['Year'].unique()))
            # Filter data based on selected year
            filtered_df = df[df['Year'] == selected_year]
            # Check if there's data after filtering
            if not filtered_df.empty:
                fig2 = px.bar(
                    filtered_df,
                    x='Continent',  # Grouped by Continent
                    y='CO2 Emissions (Tons/Capita)',  # Bar heights
                    color='Country',  # Differentiates countries within each continent
                    barmode='group',  # Grouped bars
                    title=f"CO2 Emissions by Continent in {selected_year}"
                )
                st.plotly_chart(fig2)
            else:
                st.write(f"No data available for the year {selected_year}.")
        else:
            st.write("Required columns for the grouped bar chart are missing.")
    elif visualization_type =="Area Plot":
        if 'Sea Level Rise (mm)' in df.columns and 'Country' in df.columns and 'Continent' in df.columns:
            # Create a selectbox to filter by continent
            selected_continent = st.selectbox("Select a Continent", df['Continent'].unique())

            # Filter data based on selected continent
            filtered_df = df[df['Continent'] == selected_continent]

            # Check if there's data after filtering
            if not filtered_df.empty:
                fig = px.area(
                    filtered_df,
                    x='Year',  # x-axis: Year
                    y='Sea Level Rise (mm)',  # y-axis: Sea level rise
                    color='Country',  # Different areas by Country
                    title=f"Sea Level Rise in {selected_continent} by Year"
                )
                st.plotly_chart(fig)
            else:
                st.write(f"No data available for {selected_continent}.")
        else:
            st.write("Required columns for the area chart are missing.")

    elif visualization_type == "Line Plot":
        if 'Rainfall (mm)' in df.columns and 'Continent' in df.columns and 'Year' in df.columns:
            selected_continent=st.selectbox("Select a Continent",df['Continent'].unique())
            filtered_df=df[df['Continent']==selected_continent]
            if not filtered_df.empty:
                fig4 = px.line(
                    filtered_df,
                    x='Year',# Time on x-axis
                    y='Rainfall (mm)',# Rainfall values on y-axis
                    color='Country',# Different lines for each continent
                    markers=True,# Optional: Add markers for data points
                    title="Rainfall Trends by Continent"
                    )
                st.plotly_chart(fig4)
            else:
                st.write(f"No data available for {selected_continent}.")
        else:
            st.write("Required columns for the line plot are missing.")
    elif visualization_type == "Bar Chart":
        if 'Renewable Energy (%)' in df.columns and 'Country' in df.columns and 'Continent' in df.columns and 'Year' in df.columns:
            # Create a selectbox to filter by year
            selected_year = st.selectbox("Select a Year", df['Year'].unique())

            # Filter data based on selected year and calculate average
            filtered_df = df[df['Year'] == selected_year].groupby('Country')['Renewable Energy (%)'].mean().reset_index()

            # Check if there's data after filtering
            if not filtered_df.empty:
                fig5 = px.bar(
                    filtered_df,
                    x='Country',  # Countries on x-axis
                    y='Renewable Energy (%)',  # Average renewable energy percentage on y-axis
                    color='Country',  # Different bars for each country
                    title=f"Average Renewable Energy (%) in {selected_year}",
                    labels={'Renewable Energy (%)': 'Renewable Energy (%)'}
                )
                st.plotly_chart(fig5)
            else:
                st.write(f"No data available for {selected_year}.")
        else:
            st.write("Required columns for the bar chart are missing.")

    elif visualization_type == "Choropleth Map":
        st.subheader("Choropleth Map")        
        if "Country" in df.columns and "Forest Area (%)" in df.columns:
            # Create a choropleth map
            fig6 = px.choropleth(
                df,
                locations="Country",
                locationmode="country names",
                color="Forest Area (%)",
                hover_name="Country",
                animation_frame="Year",  # Allows year-wise transitions
                title="Forest Area by Country over Years",
                color_continuous_scale=['Red','Green']
            )
            st.plotly_chart(fig6)
        else:
            st.write("The required columns for the choropleth map are missing.")

    elif visualization_type =="Scatter Plot":
        if 'CO2 Emissions (Tons/Capita)' in df.columns and 'Avg Temperature (°C)' in df.columns and 'Continent' in df.columns:
            # Create a selectbox to filter by continent
            selected_continent = st.selectbox("Select a Continent", df['Continent'].unique())

            # Filter data based on selected continent
            filtered_df = df[df['Continent'] == selected_continent]

            # Check if there's data after filtering
            if not filtered_df.empty:
                fig7 = px.scatter_3d(
                    filtered_df,
                    x='CO2 Emissions (Tons/Capita)',  # X-axis: CO2 Emissions
                    y='Avg Temperature (°C)',  # Y-axis: Average Temperature
                    z='Year',
                    color='Country',  # Different colors for each country
                    title=f"CO2 Emissions vs Avg Temperature in {selected_continent}",
                    labels={'CO2 Emissions (Tons/Capita)': 'CO2 Emissions (Tons/Capita)', 
                            'Avg Temperature (°C)': 'Average Temperature (°C)'}
                )
                st.plotly_chart(fig7)
            else:
                st.write(f"No data available for {selected_continent}.")
        else:
            st.write("Required columns for the scatter plot are missing.")

elif option == "Prediction":
    st.title("Prediction of Future Temperature")
    st.write("Predicting future temperature based on historical data using Linear Regression.")

    # Feature selection
    if 'Year' in df.columns and 'Avg Temperature (°C)' in df.columns:
        df_model = df[['Year', 'Avg Temperature (°C)']].dropna()

        # Prepare data for modeling
        X = df_model[['Year']]
        y = df_model['Avg Temperature (°C)']

        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Train Linear Regression model
        model = LinearRegression()
        model.fit(X_train, y_train)

        # Predict future years
        future_years = pd.DataFrame({'Year': range(2025, 2035)})
        predicted_temp = model.predict(future_years)

        # Evaluate the model
        mse = mean_squared_error(y_test, model.predict(X_test))
        st.write(f"Mean Squared Error for Temperature Prediction: {mse:.2f}")

        # Plot predicted temperature
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df['Year'], y=df['Avg Temperature (°C)'], name='Historical Temperature'))
        fig.add_trace(go.Scatter(x=future_years['Year'], y=predicted_temp, name='Predicted Temperature'))
        st.plotly_chart(fig)

    else:
        st.write("The required columns for prediction are missing.")

elif option == "Analysis":
    st.title("Climate Change Analysis")
    st.write("Perform in-depth analysis of climate data.")

    # Example: Calculate correlation between CO2 and temperature
    if 'CO2 Emissions (Tons/Capita)' in df.columns and 'Avg Temperature (°C)' in df.columns:
        correlation = df['CO2 Emissions (Tons/Capita)'].corr(df['Avg Temperature (°C)'])
        st.write(f"Correlation between CO2 and Temperature: {correlation:.2f}")
    else:
        st.write("Required columns for correlation analysis are missing.")